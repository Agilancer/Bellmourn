# Creature card

Fill this in for each creature before painting.

- **id** (lower_case, no spaces):
- **Name**:
- **Tier**: npc / enemy / mid_boss / big_boss / epic_boss
- **Size class** (S / M / L / H / E, see TEMPLATES.md):
- **Direction set**: 5 (same on both sides) / 8 (holds something in one hand; say which hand)
- **Height at rest** (metres):
- **Description** (silhouette, body, clothing or hide, what it carries, face, glow):
- **Palette ramps** (3-5 of: stone slate earth wood flesh blood fire gold iron moss venom mana
  arcane bone sky leather, with shade ranges, e.g. "iron 2-9, blood 2-6"):
- **Animations** (name = template, plus one line on what it does):
  - model = model
  - idle = idle
  - walk = walk
  - run = run
  - jump = jump          (or fly, fly_fast, float, float_fast, slither, slither_fast, takeoff, land)
  - <attack> = melee     (or heavy, leap, cast, shoot, throw, breath, roar, summon, blink, block)
  - hurt = hurt
  - death = death
  - corpse = corpse

`<id>.json`, zipped with the painted sheets:

```json
{"name": "", "tier": "enemy", "height_m": 1.8}
```
