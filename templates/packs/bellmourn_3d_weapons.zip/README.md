# Bellmourn 3D first-person models: weapons, shields, wands and staffs

Low-poly three.js models (binary glTF, `.glb`) for Bellmourn's first-person view, built to the
same rig as the 2D weapon templates, with texture sheets for ChatGPT to paint.

## What's in here

- `STYLE_GUIDE.md`, `bellmourn_palette.png/.json/.gpl`: the locked art style and palette.
- `apply_texture.py`: puts a painted sheet back on a model (Python 3 + Pillow + numpy).
- `viewer.html` + `manifest.json`: open the folder through any local web server
  (`python -m http.server`, then `/viewer.html`) to see the models play every rig animation.
- One folder per model:
  - `<id>.glb` (items) or `<id>_R.glb` + `<id>_L.glb` (gauntlets: right and left arm).
  - `<id>_sheet.png`: the texture sheet for ChatGPT (1536 x 1024).
  - `PROMPT.md`: the exact prompt to paste, with this model's description and part list.
  - `<id>_mask.png`, `<id>_texture.png` (flat placeholder colours), `info.json`.

## Texturing a model

1. Open the model's `PROMPT.md`. Attach `STYLE_GUIDE.md`, `bellmourn_palette.png` and
   `<id>_sheet.png` to ChatGPT and paste the prompt.
2. Save ChatGPT's painted sheet, then run:

       python apply_texture.py painted_sheet.png <model folder>

   This crops the texture square, shrinks it to the model's texture size (128 x 128 for
   items, 256 x 256 for gauntlets) using only the painted pieces (so the magenta never leaks
   in), bleeds colour past every edge so seams don't show, snaps it to the locked palette,
   saves `<id>_texture.png` and embeds it in the `.glb` file(s).
3. Reload the viewer to check it.

If ChatGPT moves or redraws the outlines, ask it to redo it keeping every piece exactly in
place: the texture only lines up with the model if the pieces stay where they are.

## Using them in the game (three.js)

- Arms/gauntlets are skinned meshes with one skeleton (`upper`, `elbow`, `fore`, `hand`,
  three bones per finger and thumb) and an `item` node. Every first-person rig animation is
  included by name (`r1h_swing`, `lks_block`, `r1s_cast`, ...), stepped at 1/35 s like the
  sprites; play them with `THREE.AnimationMixer`.
- Held items attach to the arm's `item` node: `arm.getObjectByName('item').add(item)`. The
  item's origin is the grip in the centre of the fist; nothing needs offsetting.
  Two-handed weapons go on the right arm; the left arm's own animation puts its fist on the
  grip. `r2h_walk_3d` / `r2h_swing_3d` are the 3D-only upright (Conan-style) two-hander carry.
- The first-person camera that matches the sprite rigs is a pinhole camera with a 90-degree
  horizontal field of view on a 384 x 240 screen, scaled by 0.58 toward the bottom centre;
  `viewer.html` sets this projection up (search for `fpCam`).
- Use `NearestFilter` on the textures and an unlit or Lambert material for the retro look.
- Coordinates are metres, +y up, the camera at the origin looking down -z (three.js
  convention).

## Models

- `items/onehand/arming_sword`: **Arming Sword** (296 triangles, 128px texture). A plain knightly sword: steel blade with a fuller, iron crossguard, brown leather grip, wheel pommel.
- `items/onehand/bearded_axe`: **Bearded Axe** (204 triangles, 128px texture). A Norse-style axe: steel head with a long beard on an ash haft, iron socket and band.
- `items/onehand/bone_cleaver`: **Bone Cleaver** (208 triangles, 128px texture). A brutal butcher's cleaver with a dark wood handle, brass collar and iron ring.
- `items/onehand/falchion`: **Falchion** (262 triangles, 128px texture). A heavy single-edged blade that widens toward the tip; brass guard and pommel, dark leather grip.
- `items/onehand/fang_blade`: **Serrated Fang** (224 triangles, 128px texture). A saw-toothed blade with a bone guard shaped like fangs and a bone pommel.
- `items/onehand/flanged_mace`: **Flanged Mace** (284 triangles, 128px texture). An all-iron mace with six steel flanges and a leather-wrapped grip.
- `items/onehand/morning_star`: **Morning Star** (477 triangles, 128px texture). A dark wooden haft topped with a spiked iron ball.
- `items/onehand/nail_club`: **Nail Club** (252 triangles, 128px texture). A crude wooden club studded with iron nails, with a leather hand strap.
- `items/onehand/scimitar`: **Scimitar** (242 triangles, 128px texture). A curved desert sabre with a gilded guard and cap, red cloth grip.
- `items/onehand/war_hammer`: **War Hammer** (176 triangles, 128px texture). A steel hammer face with a back spike and top spike on an iron haft.
- `items/shield_kite/banded_kite`: **Banded Kite** (656 triangles, 128px texture). A dark wooden kite shield reinforced with three iron bands.
- `items/shield_kite/knights_kite`: **Knight's Kite** (680 triangles, 128px texture). A painted wooden kite shield with iron edging and a small boss.
- `items/shield_kite/scale_kite`: **Drakescale Kite** (908 triangles, 128px texture). A green kite shield covered in rows of overlapping drake scales, bronze edging.
- `items/shield_kite/templar_kite`: **Templar Kite** (652 triangles, 128px texture). A silver kite shield with a raised red cross and gold edging.
- `items/shield_kite/thorned_kite`: **Thorned Kite** (753 triangles, 128px texture). A black obsidian kite shield with iron thorns along the edge and a central spike.
- `items/shield_round/hide_targe`: **Hide Targe** (864 triangles, 128px texture). A leather-covered targe with brass studs and a brass boss.
- `items/shield_round/ironbound`: **Iron-Bound Roundshield** (592 triangles, 128px texture). A painted wooden round shield with an iron rim and domed iron boss. The player sees the inside: planks and the grip bar.
- `items/shield_round/skull_boss`: **Skull-Boss Shield** (670 triangles, 128px texture). A dark wooden shield with a horned bone skull boss and a bone rim.
- `items/shield_round/spiked_buckler`: **Spiked Buckler** (552 triangles, 128px texture). A small steel buckler with a spiked boss and dark iron rim.
- `items/shield_round/sun_bronze`: **Sun Shield** (656 triangles, 128px texture). A bronze shield with golden sun rays radiating from a gold boss.
- `items/staff/antler_staff`: **Antler Staff** (471 triangles, 128px texture). A pale wooden staff forking into antlers, tied with a red cord.
- `items/staff/brazier_staff`: **Brazier Staff** (237 triangles, 128px texture). A dark iron staff topped with a burning brazier.
- `items/staff/caged_orb`: **Caged Orb Staff** (248 triangles, 128px texture). A brass cage holding a blue orb atop a wooden staff.
- `items/staff/crescent_staff`: **Crescent Staff** (198 triangles, 128px texture). A dark staff with a silver crescent moon and a moonstone.
- `items/staff/crosier`: **Bishop's Crosier** (304 triangles, 128px texture). A golden crosier with an ornate crook, a knop and a ruby.
- `items/staff/gnarled_staff`: **Gnarled Crystal Staff** (448 triangles, 128px texture). A twisted wooden staff whose root claws clutch a pale crystal.
- `items/staff/iron_crook`: **Iron Crook** (236 triangles, 128px texture). A dark iron staff ending in a shepherd's crook.
- `items/staff/monk_staff`: **Ringed Monk Staff** (370 triangles, 128px texture). A pale wooden staff with a brass loop and jingle rings.
- `items/staff/serpent_staff`: **Serpent Staff** (384 triangles, 128px texture). A green serpent coiling up a dark staff.
- `items/staff/skull_staff`: **Skull Staff** (296 triangles, 128px texture). A pale wooden staff crowned with a skull with ruby eyes.
- `items/twohand/claymore`: **Claymore** (340 triangles, 128px texture). A highland sword with forward-swept quillons ending in trefoils, a guard ring and a wheel pommel.
- `items/twohand/flamberge`: **Flamberge** (372 triangles, 128px texture). A wavy-bladed great sword with a gilded guard and pommel and a red grip.
- `items/twohand/glaive`: **Glaive** (222 triangles, 128px texture). A long single-edged blade with a back hook on a wooden pole.
- `items/twohand/great_axe`: **Double Great Axe** (226 triangles, 128px texture). Twin crescent steel bits on a long dark haft with an iron socket and top spike.
- `items/twohand/greatsword`: **Greatsword** (348 triangles, 128px texture). A long two-handed sword with a ricasso and parrying lugs, iron crossguard, dark leather grip, iron ball pommel.
- `items/twohand/headsman`: **Headsman's Sword** (296 triangles, 128px texture). A broad square-tipped executioner's blade with a plain dark-iron guard and pommel.
- `items/twohand/ogre_club`: **Ogre Greatclub** (388 triangles, 128px texture). A massive tree-limb club bound with iron bands and spiked.
- `items/twohand/poleaxe`: **Poleaxe** (162 triangles, 128px texture). An axe blade, hammer back and long top spike on a wooden pole with iron langets and a rondel.
- `items/twohand/scythe`: **Reaper's Scythe** (189 triangles, 128px texture). A long curved scythe blade on a dark wooden snath with a hand peg.
- `items/twohand/warmaul`: **Warmaul** (328 triangles, 128px texture). A huge dark-iron hammer head bound with iron bands on a long wooden haft.
- `items/wand/antler_wand`: **Antler Wand** (134 triangles, 128px texture). A branch of antler with two tines, leather binding.
- `items/wand/bone_wand`: **Bone Wand** (232 triangles, 128px texture). A knobbly bone wand tipped with a knucklebone, bound in sinew.
- `items/wand/crystal_wand`: **Crystal Wand** (162 triangles, 128px texture). A silver wand whose three prongs grip a pale blue crystal.
- `items/wand/ebony_wand`: **Ebony Wand** (256 triangles, 128px texture). A tapered ebony wand with three silver bands and a silver tip.
- `items/wand/ember_rod`: **Ember Rod** (224 triangles, 128px texture). A dark iron rod with a brass-caged glowing ember orb.
- `items/wand/feathered_wand`: **Feathered Charm** (104 triangles, 128px texture). A pale wooden wand with a blue bead and a fan of feathers.
- `items/wand/obsidian_shard`: **Obsidian Shard** (88 triangles, 128px texture). A jagged shard of volcanic glass with a wrapped hilt.
- `items/wand/rootwood_wand`: **Rootwood Wand** (328 triangles, 128px texture). A twisted root wand with a knot at the grip and a green seed gem at the tip.
- `items/wand/serpent_wand`: **Serpent Wand** (344 triangles, 128px texture). A bronze snake twisting to a head with ruby eyes.
- `items/wand/starfall_wand`: **Starfall Wand** (120 triangles, 128px texture). A dark wooden wand topped with a golden star.
