# Bellmourn 3D first-person models: gauntlets

Low-poly three.js models (binary glTF, `.glb`) for Bellmourn's first-person view, built to the
same rig as the 2D weapon templates, with texture sheets for ChatGPT to paint.

## What's in here

- `STYLE_GUIDE.md`, `bellmourn_palette.png/.json/.gpl`: the locked art style and palette.
- `apply_texture.py`: puts a painted sheet back on a model (Python 3 + Pillow + numpy).
- `viewer.html` + `manifest.json`: open the folder through any local web server
  (`python -m http.server`, then `/viewer.html`) to see the models play every rig animation.
- One folder per model:
  - `<id>.glb` (items) or `<id>_R.glb` + `<id>_L.glb` (gauntlets: right and left arm).
  - `<id>_sheet.png`: the texture sheet for ChatGPT (1536 x 1024).
  - `PROMPT.md`: the exact prompt to paste, with this model's description and part list.
  - `<id>_mask.png`, `<id>_texture.png` (flat placeholder colours), `info.json`.

## Texturing a model

1. Open the model's `PROMPT.md`. Attach `STYLE_GUIDE.md`, `bellmourn_palette.png` and
   `<id>_sheet.png` to ChatGPT and paste the prompt.
2. Save ChatGPT's painted sheet, then run:

       python apply_texture.py painted_sheet.png <model folder>

   This crops the texture square, shrinks it to the model's texture size (128 x 128 for
   items, 256 x 256 for gauntlets) using only the painted pieces (so the magenta never leaks
   in), bleeds colour past every edge so seams don't show, snaps it to the locked palette,
   saves `<id>_texture.png` and embeds it in the `.glb` file(s).
3. Reload the viewer to check it.

If ChatGPT moves or redraws the outlines, ask it to redo it keeping every piece exactly in
place: the texture only lines up with the model if the pieces stay where they are.

## Using them in the game (three.js)

- Arms/gauntlets are skinned meshes with one skeleton (`upper`, `elbow`, `fore`, `hand`,
  three bones per finger and thumb) and an `item` node. Every first-person rig animation is
  included by name (`r1h_swing`, `lks_block`, `r1s_cast`, ...), stepped at 1/35 s like the
  sprites; play them with `THREE.AnimationMixer`.
- Held items attach to the arm's `item` node: `arm.getObjectByName('item').add(item)`. The
  item's origin is the grip in the centre of the fist; nothing needs offsetting.
  Two-handed weapons go on the right arm; the left arm's own animation puts its fist on the
  grip. `r2h_walk_3d` / `r2h_swing_3d` are the 3D-only upright (Conan-style) two-hander carry.
- The first-person camera that matches the sprite rigs is a pinhole camera with a 90-degree
  horizontal field of view on a 384 x 240 screen, scaled by 0.58 toward the bottom centre;
  `viewer.html` sets this projection up (search for `fpCam`).
- Use `NearestFilter` on the textures and an unlit or Lambert material for the retro look.
- Coordinates are metres, +y up, the camera at the origin looking down -z (three.js
  convention).

## Models

- `gauntlets/boneward`: **Bone-Ward** (2588 triangles, 256px texture). Tribal: bleached bone plates bound to a dark hide glove with sinew, bone ribs lashed around a hide bracer, a bone elbow cap, and a shaggy brown fur sleeve.
- `gauntlets/brawler`: **Spiked Brawler** (2274 triangles, 256px texture). Studded brown leather with iron spikes on every knuckle and down the bracer, a thick leather knuckle pad, a dark leather sleeve. A pit fighter's gear.
- `gauntlets/drake`: **Drakescale** (2780 triangles, 256px texture). Overlapping rows of green drake scales down the forearm and over the fingers, bronze hand plate and elbow cap, horn studs on the knuckles, a dark red sleeve.
- `gauntlets/fiend`: **Fiend's Claw** (2812 triangles, 256px texture). Blackened, ridged demon-iron with a saw-toothed spine fin, hooked claws on every finger, a spiked elbow, and a glowing ember stone set in the back of the hand.
- `gauntlets/hunter`: **Hunter's Wraps** (2284 triangles, 256px texture). A soft brown leather glove with a short cuff, the forearm bound in pale linen wraps over a thin leather bracer, a mossy green wool sleeve. Worn, stitched, practical.
- `gauntlets/knight`: **Knight's Hourglass** (2832 triangles, 256px texture). Full plate: an hourglass cuff that flares over the wrist, broad steel finger lames, knuckle bar and hand plate, a steel vambrace and a winged elbow couter over chain mail.
- `gauntlets/mailed`: **Mailed Glove** (2104 triangles, 256px texture). A riveted chain-mail glove and mail sleeve, a polished steel plate cuff, a steel knuckle bar and a plain steel elbow cop. Grey, cold, functional.
- `gauntlets/runebound`: **Runebound Glove** (2192 triangles, 256px texture). A mage's fingerless violet glove and robe sleeve, silver bands carved with runes around the forearm, and a pale blue focus crystal set in a silver mount on the back of the hand.
- `gauntlets/templar`: **Gilded Templar** (2960 triangles, 256px texture). Holy plate: polished steel with gold trim, a fluted bell cuff, a gilded knuckle bar, a gold sun medallion on the back of the hand, a royal blue tabard sleeve over mail.
- `gauntlets/wayfarer`: **Wayfarer's Gauntlet** (2940 triangles, 256px texture). The player's default arm: blackened-iron finger lames and knuckle bar over a dark leather glove, a domed iron hand plate with brass rivets, a brown leather bracer laced with pale rawhide between two iron bands, and a wine-red wool sleeve.
