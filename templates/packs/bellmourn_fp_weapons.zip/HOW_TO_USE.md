# How to use this pack with ChatGPT

Attach STYLE_GUIDE.md, bellmourn_palette.png and ONE rig's `<rig>_template.png`, then paste:

---
You are painting first-person weapon sprites for Bellmourn, a 1990s-style dark fantasy game.
Follow the attached STYLE_GUIDE.md exactly; it is locked. Use only colours from
bellmourn_palette.png.

The attached sheet is a rig: every cell is one full game screen (384x240) showing one animation
frame. Paint the locked Bellmourn gauntlet arm(s) holding: <DESCRIBE THE WEAPON HERE>.

- Match the rig in every cell: fist on the green G dot, knuckles toward the cyan arrow, the
  weapon along the yellow proxy (shorter or longer weapons keep the same grip and angle).
- Where a cell is marked SMEAR, paint a motion smear; where it is marked FIRE, paint a muzzle
  flash at the orange burst.
- Then replace every guide mark, label, dot, line and the grey mannequin with flat #FF00FF.
- Keep the sheet size and every black cell border exactly where they are.
- Same weapon, same arm, same lighting in every frame. Hard pixel edges, no outlines, no text.
---

Each rig's notes (on the sheet and in `<rig>_frames.json`) say what the animation does.
`<rig>_frames.json` also gives each frame's cell, timing in tics (1/35 s), events
(hit / fire / smear) and the full 3D arm pose, so the game can slice and time the sheet.
